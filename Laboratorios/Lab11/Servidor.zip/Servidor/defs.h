#ifndef defs_H
#define defs_H 

#define  NUM_HILOS 4

#endif