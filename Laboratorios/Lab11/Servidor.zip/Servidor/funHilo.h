#ifndef funHilo_H
#define funHilo_H 

void * funHilo(void *arg);

#endif