#ifndef procesamiento_H
#define procesamiento_H


void procesarImagen(void);

#endif